<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Stype extends Model
{
    //
}
