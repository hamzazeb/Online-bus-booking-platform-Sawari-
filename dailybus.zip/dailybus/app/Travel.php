<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

use App\Slip;

class Travel extends Model
{
	
     protected $fillable = ['member_id', 'types_id']; 


}


