<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Type;
use App\Member;
use App\Travel;
use App\Slip;
use App\Project;

class ServiceController extends Controller
{
    public function index()
    {
    	// return view('welcome');
    }

	public function create()
    {
    	//return view('welcome');
    }

    public function store()
    {	


            $data = Travel::latest()->first();
            $data->update([ //updateing to myroutes table
                            'member_id' => Member::latest()->first()->id,
                            'types_id' => Type::latest()->first()->id,
                         ]); 

            $slipdata = Slip::latest()->first();
            $slipdata->update([
                                'no_of_seats' => request('no_of_seats'),
                                'service_name' => request('service_name'),
                                'service_type' => request('service_type'),
                             ]);


            

			return redirect('receipt');
    }
}
