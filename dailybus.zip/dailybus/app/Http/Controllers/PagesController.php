<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Project;
use App\Facilitie;
use App\Travel;
use App\Member;
use App\Type;
use App\Receipt;
use App\Stype;
use App\Slip;

class PagesController extends Controller
{
    public function home()
    {
		return view('welcome', [
    	'foo' => 'Sawari'
    ]);

    }

    public function about()
    {
    	return view('about');
    }

    public function contact()
    {
    	return view('contact');
    }

     public function booking()
    {
        $projects = Project::all();
        $facilities = Facilitie::all();
        $travels1 = Travel::latest()->first()->from;
        $travels2 = Travel::latest()->first()->where;
        $travel_type = Stype::latest()->first()->service_type;
        $members = Member::all();

        return view('booking', compact('projects','facilities','travels1','travels2','travel_type','services','members'));
        
    }

     public function customer()
    {   
        $projects = Project::all();


        return view('customer', compact('projects'));
    }

     public function help()
    {
        return view('help');
    }

     public function receipt()
    {

        $projects = Project::all();
        $travels = Travel::all();
        $members = Member::all();
        $slips = Slip::all();
        $types = Type::all();

        return view('receipt', compact('projects','travels','members','slips','types'));
    }

   
}
