<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Member;
use App\Slip;

class MembersController extends Controller
{
    public function index()
    {
    	// return view('welcome');
    }

	public function create()
    {
    	//return view('welcome');
    }

    public function store()
    {

    		$member = new member();
    		$member->name = request('name');
    		$member->cnic = request('cnic');
    		$member->mobile = request('mobile'); 	 	
			$member->save();

            $data = Slip::latest()->first();
            $data->update([ //updateing to myroutes table
                            'name' => request('name'),
                         ]); 

			return redirect('booking');
    }

}
