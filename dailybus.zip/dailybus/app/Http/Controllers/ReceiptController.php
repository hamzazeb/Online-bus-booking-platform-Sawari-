<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Project;
use App\Travel;
use App\Service;
use App\Member;

class ReceiptController extends Controller
{
   public function index()
    {

		    // $projectfrom = Project::latest()->sfrom;
      //   $projectto = Project::latest()->sto;
     //    $travelfrom = Travel::latest()->first()->from;
     //    $travelto = Travel::latest()->first()->where;
     //    $services = Service::last();
     //    $members = Member::last();

     //    // if($projectfrom == $travelfrom && $projectto == $travelto)
     //    // {
     //    //   $projects = 
     //    // }

    	// return view('receipt', compact(['travelfrom', 'travelto','projects','services','members']));
    }

     public function create()
    {

    	return view('projects.create');
    }

     public function store()
    {

  //   	$project = new Project();

		// $project->service_name = request('service_name');
		// $project->service_type = request('service_type');
  //       $project->sfrom = request('sfrom');
  //       $project->sto = request('sto');
  //       $project->departure = request('departure');
  //       $project->duration = request('duration');
  //       $project->arrival = request('arrival');
  //       $project->fare = request('fare');

		// $project->save();

		// return redirect('/projects');
    //	return request()->all();
    }
}
