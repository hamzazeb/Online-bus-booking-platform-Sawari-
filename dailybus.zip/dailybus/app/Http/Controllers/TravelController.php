<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Travel;
use App\Member;
use App\Slip;

class TravelController extends Controller
{
   public function index()
    {
        $travels = Travel::all();

    	 return view('deltravel.index', compact('travels'));
    }

	public function create()
    {
    	//return view('welcome');
    }

    public function store()
    {	
    		$travel = new Travel();
    		$travel->from = request('from');
    		$travel->where = request('where');
    		$travel->date = request('date'); 	 	
			$travel->save();

            $slip = new Slip();
            $slip->from = request('from');
            $slip->where = request('where');
            $slip->date = request('date');
            $slip->travel_id = Travel::latest()->first()->id;
            $slip->save();


			return redirect('customer');
    }


  
}
