<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Project;
use App\Travel;
use App\Stype;
use App\Type;

class ProjectsController extends Controller
{
    public function index()
    {

		$projects = Project::all();

        $travels = Travel::all();

    	return view('projects.index', compact(['projects','travels']));
    }

     public function create()
    {

    	return view('projects.create');
    }

     public function store()
    {
        $stype = new  Stype();

        $stype->service_type = request('type');
        $stype->save();

    	$project = new Project();

		$project->service_name = request('service_name');
        $project->service_type = request('type');
        $project->sfrom = request('sfrom');
        $project->sto = request('sto');
        $project->departure = request('departure');
        $project->duration = request('duration');
        $project->arrival = request('arrival');
        $project->fare = request('fare');
		$project->save();

        $type = new Type();
        $type->stypes_id = $stype->id;
        $type->project_id = $project->id;
        $type->save();

		return redirect('/projects');
    //	return request()->all();
    }

  
}
