<?php

namespace App\Http\Controllers;

use App\Facilitie;

use Illuminate\Http\Request;

class FacilitiesController extends Controller
{
    public function index()
    {

    	$facilities = Facilitie::all();


    	return view('facilities.index', compact('facilities'));
    }

    public function create()
    {

    	return view('facilities.create');

    }

    public function store()
    {
    	$facilitie = new Facilitie();

    	$facilitie->service_id = request('service_id');
    	$facilitie->Wifi = request('Wifi');
    	$facilitie->Refreshment = request('Refreshment');
    	$facilitie->Newspaper = request('Newspaper');
    	$facilitie->AC = request('AC');
    	$facilitie->Entertainment = request('Entertainment');

    	$facilitie->save();

    	return redirect('/projects');
    }
}
