<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Slip extends Model
{
    
      protected $fillable = ['name','service_name', 'service_type', 'no_of_seats']; 



}



