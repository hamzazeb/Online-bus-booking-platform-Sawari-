<!DOCTYPE html>
<html>
    <head>
        <title><?php echo $__env->yieldContent('title', 'Sawari'); ?></title>
        <link href="<?php echo e(asset('css/stylesheet.css')); ?>" rel="stylesheet">
    </head>

    <body>
        <div>
        <div class="logodiv">
            <a href="/"><img class="logo" src="/images/logo.png" \></a>
        </div>

        <div class="menudiv">
        <ul >
            <li><a href="/" >Find a Sawari</a></li>
            <li><a href="/help" >Help</a></li>
            <li><a href="/about" >About Us</a></li>
        </ul>
        <div>
            <a href="/"><img src="/images/userProfile.png" \></a>
        </div>
        </div>
        </div>
        
         <?php echo $__env->yieldContent('content'); ?>
        

    </body>
</html><?php /**PATH C:\Users\Hamza Zeb\dailybus\resources\views/layout.blade.php ENDPATH**/ ?>