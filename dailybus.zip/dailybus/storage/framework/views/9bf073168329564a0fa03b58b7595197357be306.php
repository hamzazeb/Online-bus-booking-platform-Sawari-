<!DOCTYPE html>
<html>
    <head>
        <title>Facilities</title>
        <style>
        	h1{
        		text-align: center;
        	}
        	.nameshere{
        		width=20px;
        		margin-left: 400px;
        		
        		padding:20px;
        	}
        	table{
        		width:100%;
        	}
        	table, th, td {
 				 border: 1px solid black;
 				 padding:5px;
 				 font-family: calibri;
 				 font-size: 18px;
                 text-align:center;
			}
			th {
  				height: 30px;
  				background-color: orange;
                font-family: raleway;
  				color:black;
  				font-size: 17px;
			}
			td:hover{
				border-bottom-color:red;

			}

        </style>
    </head>
    <body>
   <?php if(isset(Auth::user()->email)): ?>
    <div class="alert alert-danger success-block" id="welcomediv">
     <span class="welcome">Welcome <strong style="text-decoration: underline;"><?php echo e(Auth::user()->name); ?></strong></span>
     <br />
     <a class="welcome1" href="<?php echo e(url('/main/logout')); ?>"><button>Logout</button></a>
    </div>
   <?php else: ?>
    <script>window.location = "/main";</script>
   <?php endif; ?>
        <h1>Facilities</h1>
        
            <table>
            <tr>
                <th>Service ID</th>
                <th>WiFi</th>
                <th>Refreshment</th>
                <th>Newspaper</th>
                <th>AC</th>
                <th>Entertainment</th>
            </tr>
            <?php $__currentLoopData = $facilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facilitie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($facilitie->service_id); ?></td>
                <td><?php echo e($facilitie->Wifi); ?></td>
                <td><?php echo e($facilitie->Refreshment); ?></td>
                <td><?php echo e($facilitie->Newspaper); ?></td>
                <td><?php echo e($facilitie->AC); ?></td>
                <td><?php echo e($facilitie->Entertainment); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </body>
</html><?php /**PATH C:\Users\Hamza Zeb\dailybus\resources\views/facilities/index.blade.php ENDPATH**/ ?>