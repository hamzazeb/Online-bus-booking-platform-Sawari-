<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <style>
        		h1{
        			text-align:center;
        			font-family: calibri;
        		}
        		form div input{
						padding:13px;
						border-width: 1px;
						border-left-color:black;
						border-right-color:black;
						border-bottom-color:black;
						border-top-color:gray;
						width:350px;
						opacity:0.4;

					}
				form div{
					text-align: center;
				}
				button{
					width:150px;
					padding: 13px;
					background-color: orange;
					margin-top: 10px;
				}
form input:hover{
	opacity:0.8;
}
        		}
        </style>
    </head>
    <body>

        <h1>Add Facilities Here</h1>

        <form method="POST" action="/projects">
        	<?php echo e(csrf_field()); ?>

			
			<!-- Facilities -->
			<div>
				<input type="name" name="service_name" placeholder="Service Name">
			</div>
			<div>
				<input type="wifi" name="Wifi" placeholder="Wifi">
			</div>
			<div>
				<input type="refreshment" name="Refreshment" placeholder="Refreshment">
			</div>
			<div>
				<input type="newspaper" name="Newspaper" placeholder="Newspaper">
			</div>
			<div>
				<input type="ac" name="AC" placeholder="AC">
			</div>
			<div>
				<input type="entertainment" name="Entertainment" placeholder="Entertainment">
			</div>

			<div>
				<button type="submit">Submit Service</botton>
			</div>

		</form>


    </body>
</html><?php /**PATH C:\Users\Hamza Zeb (RFHKM)\dailybus\resources\views/projects/createfacility.blade.php ENDPATH**/ ?>