<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <style>
            h1{
                text-align: center;
            }
            .nameshere{
                width=20px;
                margin-left: 400px;
                
                padding:20px;
            }
            table{
                width:100%;
            }
            table, th, td {
                 border: 1px solid black;
                 padding:5px;
                 font-family: calibri;
                 font-size: 18px;
            }
            th {
                height: 30px;
                background-color: orange;
                font-family: raleway;
                color:black;
                font-size: 17px;
            }
            td:hover{
                border-bottom-color:red;
            }

        </style>
    </head>
    <body>

        <h1>List of Travels</h1>
        <table>
            <tr>
                <th>ID</th>
                <th>From</th>
                <th>Where</th>
                <th>Date</th>
            </tr>
            <?php $__currentLoopData = $travels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $travel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($travel->id); ?></td>
                <td><?php echo e($travel->from); ?></td>
                <td><?php echo e($travel->where); ?></td>
                <td><?php echo e($travel->date); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>

    </body>
</html><?php /**PATH C:\Users\Hamza Zeb (RFHKM)\dailybus\resources\views/deltravel/index.blade.php ENDPATH**/ ?>