<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <style>
        		h1{
        			text-align:center;
        			font-family: calibri;
        		}
        		form div input{
						padding:13px;
						border-width: 1px;
						border-left-color:black;
						border-right-color:black;
						border-bottom-color:black;
						border-top-color:gray;
						width:350px;
						opacity:0.4;

					}
				form div{
					text-align: center;
				}
				button{
					width:150px;
					padding: 13px;
					background-color: orange;
					margin-top: 10px;
				}
form input:hover{
	opacity:0.8;
}
.welcome{
					font-size: 23px;
					font-family: raleway;
					text-align: right;
					padding:10px;

				}
				button:hover{
					border:1px black solid;
				}
				 span{
					line-height: 80px;
					color:white;
					font-family: raleway;
				}
				.welcome1 button{
					font-size: 16px;
					font-family: raleway;
					text-align: center;
					padding:10px;
					color:white;
					background-color:orange;
					float:right;
					margin-top: -65px;
					margin-right: 20px;
					opacity: 0.8px;
				}

				#welcomediv{
					height: 83px;
					width:100%;
					background-color: #F5BCBA;
				}
        		}
        </style>
    </head>
    <body>

    	<?php if(isset(Auth::user()->email)): ?>
    <div class="alert alert-danger success-block" id="welcomediv">
     <span class="welcome">Welcome <strong style="text-decoration: underline;"><?php echo e(Auth::user()->name); ?></strong></span>
     <br />
     <a class="welcome1" href="<?php echo e(url('/main/logout')); ?>"><button>Logout</button></a>
    </div>
   <?php else: ?>
    <script>window.location = "/main";</script>
   <?php endif; ?>

        <h1>Add Facilities Here</h1>
        <b style="color:blue;">Enter 1 if available <br> Enter 0 if not available</b>

        <form method="POST" action="/facilities">
        	<?php echo e(csrf_field()); ?>

			
			<!-- Facilities -->
			<div>
				<input type="name" name="service_id" placeholder="Service ID ">
			</div>
			<div>
				<input type="wifi" name="Wifi" placeholder="Wifi">
			</div>
			<div>
				<input type="refreshment" name="Refreshment" placeholder="Refreshment">
			</div>
			<div>
				<input type="newspaper" name="Newspaper" placeholder="Newspaper">
			</div>
			<div>
				<input type="ac" name="AC" placeholder="AC">
			</div>
			<div>
				<input type="entertainment" name="Entertainment" placeholder="Entertainment">
			</div>

			<div>
				<button type="submit">Submit Service</botton>
			</div>

		</form>


    </body>
</html><?php /**PATH C:\Users\Hamza Zeb (RFHKM)\dailybus\resources\views/facilities/create.blade.php ENDPATH**/ ?>