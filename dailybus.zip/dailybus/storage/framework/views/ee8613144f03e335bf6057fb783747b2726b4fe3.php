<!DOCTYPE html>
<html>
    <head>
        <title></title>

        <style>
        		h1{
        			text-align:center;
        			font-family: calibri;
        		}
        		form div input{
						padding:13px;
						border-width: 2px;
						border-left-color:black;
						border-right-color:black;
						border-bottom-color:black;
						border-top-color:gray;
						width:350px;
						opacity:0.4;
						border-color:white;
						border-bottom-color: black;
					}
				form div .sc1{
					width:283px;
					margin-left:7px;
				}
				form div{
					text-align: center;
					padding:2px;


				}
				button{
					width:150px;
					padding: 13px;
					background-color: orange;
					margin-top: 10px;
					color:white;
					font-family: raleway;
					font-size: 16px;
				}
				button:hover{
					border:1px black solid;
				}
				select{
					width:70px;
					height:43px;
					margin-left:px;
				}
				form input:hover{
					opacity:0.8;
				}
				.welcome{
					font-size: 23px;
					font-family: raleway;
					text-align: right;
					padding:10px;

				}
				 span{
					line-height: 80px;
					color:white;
					font-family: raleway;
				}
				.welcome1 button{
					font-size: 16px;
					font-family: raleway;
					text-align: center;
					padding:10px;
					color:white;
					background-color:orange;
					float:right;
					margin-top: -65px;
					margin-right: 20px;
					opacity: 0.8px;
				}

				#welcomediv{
					height: 83px;
					width:100%;
					background-color: #F5BCBA;
				}
        		}
        </style>
    </head>
    <body>

<?php if(isset(Auth::user()->email)): ?>
    <div class="alert alert-danger success-block" id="welcomediv">
     <span class="welcome">Welcome <strong style="text-decoration: underline;"><?php echo e(Auth::user()->name); ?></strong></span>
     <br />
     <a class="welcome1" href="<?php echo e(url('/main/logout')); ?>"><button>Logout</button></a>
    </div>
   <?php else: ?>
    <script>window.location = "/main";</script>
   <?php endif; ?>

        <h1>Add New Bus Service Here</h1>

        <form method="POST" action="/projects">
        	<?php echo e(csrf_field()); ?>

			<div>
				<input class="sc1" type="name" name="service_name" placeholder="Service Name">

				<select type="text" id="type" name="type" placeholder="">
    				<option value="bus">Bus</option>
      				<option value="hiace">Hiace</option>
      				<option value="cargo">Cargo</option>
				</select>
			</div>

			<div>
				<input type="sfrom" name="sfrom" placeholder="From">
			</div>

			<div>
				<input type="sto" name="sto" placeholder="To">
			</div>

			<div>
				<input type="departure" name="departure" placeholder="Departure">
			</div>

			<div>
				<input type="duration" name="duration" placeholder="Duration">
			</div>

			<div>
				<input type="arrival" name="arrival" placeholder="Arrival">
			</div>

			<div>
				<input type="fare" name="fare" placeholder="Fare">
			</div>

			<div>
				<button type="submit">Submit Service</botton>
			</div>
			
		</form>


    </body>
</html><?php /**PATH C:\Users\Atif Ur Rahman\dailybus\resources\views/projects/create.blade.php ENDPATH**/ ?>