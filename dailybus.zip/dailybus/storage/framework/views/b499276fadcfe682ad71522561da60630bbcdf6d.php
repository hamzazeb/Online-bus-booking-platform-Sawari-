	
	
	
	<?php $__env->startSection('content'); ?>
<html>
<head>
	<link href="<?php echo e(asset('css/stylesformain.css')); ?>" rel="stylesheet">
</head>
<body class="mainbg">

	

 
 <div class="belowheader">
 	<!-- form -->
<div class="firstform">
	<div class="firstformdata">
		<strong>Find your next favourite Sawari</strong><br><br>
  		<form method="POST" action="/welcome">
      <?php echo e(csrf_field()); ?>

    		<label ><span>Where</span></label><br>
    		<select type="text" id="destinition" name="where" placeholder="">
      			<option value="abbottabad">Abbottabad</option>
      			<option value="peshawar">Peshawar</option>
      			<option value="islamabad">Islamabad</option>
      			<option value="lahore">Lahore</option>
      			<option value="karachi">Karachi</option>
      			<option value="multan">Multan</option>
      			<option value="faisalabad">Faisalabad</option>
      			<option value="Haripur">Haripur</option>
      			<option value="rawalpindi">Rawalpindi</option>
			</select>
   <br><br>
    		<label ><span>From</span></label><br>
    		<select type="text" id="destinition" name="from" placeholder="">
    			<option value="islamabad">Islamabad</option>
      			<option value="abbottabad">Abbottabad</option>
      			<option value="peshawar">Peshawar</option>
      			<option value="lahore">Lahore</option>
      			<option value="karachi">Karachi</option>
      			<option value="multan">Multan</option>
      			<option value="faisalabad">Faisalabad</option>
      			<option value="Haripur">Haripur</option>
      			<option value="rawalpindi">Rawalpindi</option>
			</select>
   <br><br>	
    		<label><span>When</span></label><br>
    		<input type="date" id="date" name="date" placeholder="">
  	<br><br>

        <center><button type="submit" class="submitmysawari">
    		FIND MY SAWARI</button></center>
  		</form>
  	</div>
	</div>

 	<!-- form end -->


 		<div class="logodiv">
           <a href="/"> <img class="logo" src="/images/logo.png" \></a>
        </div>

        <div class="menudiv">
        <ul >
            <li><a href="/" >Find a Sawari</a></li>
            <li><a href="/help" >Help</a></li>
            <li><a href="/about" >About Us</a></li>
        </ul>
        <div>
            <a href="/"><img src="/images/userProfileBlack.png" \></a>
        </div>
        </div>
 
    </div>

 <div class="citieswelove">
 	<strong>Trending Destinations</strong>
 	<div>
 		<div>
 			<img src="/images/cities/Islamabad.png" \>
 		</div>
 		<div>
 			<img src="/images/cities/Lahore.png" \>
 		</div>
 		<div>
 			<img src="/images/cities/Karachi.png" \>
 		</div>
 		<div>
 			<img src="/images/cities/Multan.png" \>
 		</div>
 		<div>
 			<img src="/images/cities/Faisalabad.png" \>
 		</div>
 	</div>
 	
 	<div class="banner">
 			<img src="/images/cities/Banner.png" \>
 	</div>

	<div class="whysawari">
 			<strong>Why Sawari?</strong>
 			<p>
 				Sawari in Pakistan's leading bus booking site, with its premium features like live-tracking and on the go payment, Sawari stands out among all <br>of its competitors.
 				<br>
				When choosing Sawar to book your rides, you can be sure of absolutely Premium quality and a guaranteed memorable experience.
 			</p>
 	</div>

 	<div class="upcomming">
 		<strong>Upcomming Features</strong>
 		<div>
 			<div class="one"><img src="/images/cities/Feature_Track.png" \></div>
 			<div class="two"><img src="/images/cities/Feature_Pay.png" \></div>
 			<div class="three"><img src="/images/cities/Feature_Promo.png" \></div>
 		</div>
 	</div>

 	<div class="download">
 		<div class="first">
 			<strong>Download the app</strong>
 			<p>
 				Book your Sawaris on the go<br> by downloading our app.<br>
We promise not to bother you<br> with spam and annoying<br> notifications.
 			</p>
 			<img src="/images/cities/Google_Play.png" \>
 			<img src="/images/cities/App_Store.png" \>
 		</div>
 		<div class="second">
 			<img id="myapp" src="/images/cities/Sawari_mobile.png" \>
 		</div>
 	</div>

 </div>
 <!-- footer -->
 <div class="footer">
 	<div class="footertext"><br>
		 	<div id="one"><img src="/images/cities/Sawari_White.png" \></div>
		 	<div id="two">All Right Reserved. <b>Hamza</b></div>
		 	<div id="three"><img src="/images/cities/Social_Media_Icon.png" \></div>
	 </div>
	 
 </div>

</body>
</html>
	<?php $__env->stopSection(); ?>	
		
	

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Hamza Zeb\dailybus\resources\views/welcome.blade.php ENDPATH**/ ?>