<!DOCTYPE html>
<html>
    <head>
        <title>Booking</title>
        <link href="<?php echo e(asset('css/stylesformain.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/stylesheet.css')); ?>" rel="stylesheet">
    </head>

    <body>
      <div class="bookingmenu">
        <div class="logodiv">
            <a href="/"><img class="logo" src="/images/logo.png" \></a>
        </div>

        <div class="menudiv">
        <ul >
            <li><a href="/" >Find a Sawari</a></li>
            <li><a href="/help" >Help</a></li>
            <li><a href="/about" >About Us</a></li>
        </ul>
        <div>
            <a href="/"><img src="/images/userProfileBlack.png" \></a>
        </div>
        </div>
      </div>
        
      <div class="bookingcontainer">
         <div class="leftone">
         		<div class="lfirst">
         			<strong>Sort By</strong><br>

         			<button>Fare</button>
         			<button>Ratings</button>
         			<button>Seats</button>
         		</div>	
         		<div class="lsecond">
         			<strong>FILTERS</strong>
         			<br><br>
         			<label>
         				<span>Air-Conditioned</span>
  						<input type="checkbox">
					</label><br>
					<label>
         				<span>Refreshments</span>
  						<input type="checkbox">
					</label><br>
					<label>
         				<span>Entertainment System</span>
  						<input type="checkbox">
					</label>
         		</div>

         		<div class="lthird"><br>
         			<strong>Departures</strong>
         			<br>
         			<label>
         				<span>Day time</span>
  						<input type="checkbox">
					</label><br>
					<label>
         				<span>Night time</span>
  						<input type="checkbox">
					</label><br>	
         		</div>
         		<div class="lfourth"><br>
         			<strong>Bus Service</strong>
         			<br>
         			<label>
         				<span>Daewoo Express</span>
  						<input type="checkbox">
					</label><br>
					<label>
         				<span>Faisal Movers</span>
  						<input type="checkbox">
					</label>
					<br>
         			<label>
         				<span>Bilal Travels</span>
  						<input type="checkbox">
					</label><br>
					<label>
         				<span>Islamabad Express</span>
  						<input type="checkbox">
					</label>
					<br>
         			<label>
         				<span>Pindi Coaches</span>
  						<input type="checkbox">
					</label><br>
					<label>
         				<span>Niazi Express</span>
  						<input type="checkbox">
					</label>
					<br>
         			<label>
         				<span>Moterway Express</span>
  						<input type="checkbox">
					</label><br>	
         		</div>
         </div>
      
         <div class="rightone">
         		<div class="rfirst">
                    <div class="rfirst1" >
                       
                    </div>
                    <div><b>Departure</b></div>
                    <div><b>Duration</b></div>
                    <div><b>Arrival</b></div>
                    <div><b>Fare</b></div>
                    
        
                    <div class="rfirst6"> <b>Send Payment At</b></div>

                </div>
      
                
                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if( $travels1 == $project->sfrom and $travels2 == $project->sto): ?>

         		<div class="rsecond">
                    <div class="rsecond1" name="service_name1" value="<?php echo e($project->service_name); ?>"><b><?php echo e(strtoupper($project->service_name)); ?> - <span style="color:green;font-size: 13px;"><?php echo e(strtoupper($project->service_type)); ?></span></b>
                        <br>
                         <?php $__currentLoopData = $facilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facilitie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($facilitie->service_id == $project->id): ?>
                            <?php if($facilitie->Wifi == 1): ?>
                                <img class="rs1" src="/images/facilities/wifi.png" \>
                            <?php else: ?>
                                <b></b>
                            <?php endif; ?>

                            <?php if($facilitie->Refreshment == 1): ?>
                                <img class="rs2" src="/images/facilities/refreshment.png" \>
                            <?php else: ?>
                                <b></b>
                            <?php endif; ?>

                            <?php if($facilitie->Newspaper == 1): ?>
                                <img class="rs3" src="/images/facilities/newspaper.png" \>
                            <?php else: ?>
                                <b></b>
                            <?php endif; ?>

                            <?php if($facilitie->AC == 1): ?>
                                <img class="rs4" src="/images/facilities/ac.png" \>
                            <?php else: ?>
                                <b></b>
                            <?php endif; ?>

                            <?php if($facilitie->Entertainment == 1): ?>
                                <img class="rs4" src="/images/facilities/entertainment.png" \>
                            <?php else: ?>
                                <b></b>
                            <?php endif; ?>
                        <?php endif; ?>                
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

                    </div>
                    <div style="color:green;font-size: 21px" name="departure1" value="<?php echo e($project->departure); ?>">
                        <?php echo e($project->departure); ?>

                    </div>
                    <div style="color:brown;font-size: 21px" name="duration1" value="<?php echo e($project->duration); ?>">
                        <?php echo e($project->duration); ?>h
                    </div>
                    <div style="font-size: 21px" name="arrival1" value="<?php echo e($project->arrival); ?>">
                        <?php echo e($project->arrival); ?>

                    </div>
                    <div style="font-size: 21px" name="fare1" value="<?php echo e($project->fare); ?>">
                        PKR <?php echo e($project->fare); ?>

                    </div>
                    <div class="rsecond6">
                            <span>Acc # 03165467510</span><br><br>
                            <a href="https://www.easypaisa.com.pk/easypay/onlinepayments" target="_blank"><img src="/images/easypaisa.png"></a>
                            
                        
                    </div>
                </div>
         <?php endif; ?>  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                

<form method="POST" action="/receipt">
      <?php echo e(csrf_field()); ?>

      <br>
            <label ><span>Select You Service Here</span></label>
            <select style="margin-left: 18px;"  type="text" id="randommm" name="service_name" placeholder="">
                <option value="daeweoo express">DAEWOO EXPRESS</option>
                <option value="moterway express">MOTERWAY EXPRESS</option>
                <option value="niazi express">NIAZI EXPRESS</option>                        
                <option value="bilal travels">BILAL TRAVELS</option>
                <option value="faisal movers">FAISAL MOVERS</option>
            </select>
<br>
            <label ><span>Select Service Type</span></label>
            <select style="margin-left: 53px;" type="text" id="randommm" name="service_type" placeholder="">
                <option value="bus">Bus</option>
                <option value="hiace">Hiace</option>
                <option value="cargo">Cargo</option>
            </select>
<br>

            <label ><span>Select No of Seats</span></label>
            <select style="margin-left: 64px;" type="text" id="randommm" name="no_of_seats" placeholder="">
                <option value=1>1</option>
                <option value=2>2</option>
                <option value=3>3</option>
                <option value=4>4</option>
            </select>   
            

             <button  type="submit" class="randomm">BOOK MY SAWARI</button>
                    
    </form>           
         		
         </div>
         
     </div>

    </body>
</html><?php /**PATH C:\Users\Atif Ur Rahman\dailybus\resources\views/booking.blade.php ENDPATH**/ ?>