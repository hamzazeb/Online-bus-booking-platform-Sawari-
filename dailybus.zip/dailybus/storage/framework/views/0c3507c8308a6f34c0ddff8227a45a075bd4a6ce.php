<!DOCTYPE html>
<html>
    <head>
        <title>Help</title>
        <link href="<?php echo e(asset('css/stylesformain.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/stylesheet.css')); ?>" rel="stylesheet">
    </head>

    <body>
      <div class="bookingmenu">
        <div class="logodiv">
            <a href="/"><img class="logo" src="/images/logo.png" \></a>
        </div>

        <div class="menudiv">
        <ul >
            <li><a href="/" >Find a Sawari</a></li>
            <li><a href="/help" >Help</a></li>
            <li><a href="/about" >About Us</a></li>
        </ul>
        <div>
            <a href="/"><img src="/images/userProfileBlack.png" \></a>
        </div>
        </div>
      </div>
    
    <div class="helpcontainer">
      <br><br>
      <b><span>How does.</span> <img class="helplogo" src="/images/logo.png" \> <span>work.</span><b>
      <br>
      <p>Sawari is a user friendly platform, which works in 5 simple steps.</p>
      <br>
      <img class="im2" src="/images/helpBar.png" \>
      
    </div>
        
    </body>
</html><?php /**PATH C:\Users\Hamza Zeb\dailybus\resources\views/help.blade.php ENDPATH**/ ?>