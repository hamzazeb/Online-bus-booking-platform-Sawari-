<?php $__env->startSection('title', 'Contact Us'); ?>

<?php $__env->startSection('content'); ?>

    <h1>Contact Us</h1>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Hamza Zeb (RFHKM)\dailybus\resources\views/contact.blade.php ENDPATH**/ ?>