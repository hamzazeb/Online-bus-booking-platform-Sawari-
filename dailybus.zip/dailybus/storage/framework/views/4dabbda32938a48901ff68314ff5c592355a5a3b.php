<!DOCTYPE html>
<html>
    <head>
        <title>Yout Receipt</title>
        <link href="<?php echo e(asset('css/stylesformain.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/stylesheet.css')); ?>" rel="stylesheet">
    </head>

    <body>
      <div class="bookingmenu">
        <div class="logodiv">
            <a href="/"><img class="logo" src="/images/logo.png" \></a>
        </div>

        <div class="menudiv">
        <ul >
            <li><a href="/" >Find a Sawari</a></li>
            <li><a href="/help" >Help</a></li>
            <li><a href="/about" >About Us</a></li>
        </ul>
        <div>
            <a href="/"><img src="/images/userProfileBlack.png" \></a>
        </div>
        </div>
      </div>
        
      <div class="bookingcontainer">
         <div class="leftone">
         		<div class="lfirst">
         			<strong>Sort By</strong><br>

         			<button>Fare</button>
         			<button>Time</button>
         			
         		</div>	
         		<div class="lsecond">
         			<strong>FILTERS</strong>
         			<br><br>
         			<label>
         				<span>Air-Conditioned</span>
  						<input type="checkbox">
					</label><br>
					<label>
         				<span>Refreshments</span>
  						<input type="checkbox">
					</label><br>
					<label>
         				<span>Entertainment System</span>
  						<input type="checkbox">
					</label>
         		</div>

         		<div class="lthird"><br>
         			<strong>Departures</strong>
         			<br>
         			<label>
         				<span>Day time</span>
  						<input type="checkbox">
					</label><br>
					<label>
         				<span>Night time</span>
  						<input type="checkbox">
					</label><br>	
         		</div>
         		<div class="lfourth"><br>
         			<strong>Bus Service</strong>
         			<br>
         			<label>
         				<span>Daewoo Express</span>
  						<input type="checkbox">
					</label><br>
					<label>
         				<span>Faisal Movers</span>
  						<input type="checkbox">
					</label>
					<br>
         			<label>
         				<span>Bilal Travels</span>
  						<input type="checkbox">
					</label><br>
					<label>
         				<span>Islamabad Express</span>
  						<input type="checkbox">
					</label>
					<br>
         			<label>
         				<span>Pindi Coaches</span>
  						<input type="checkbox">
					</label><br>
					<label>
         				<span>Niazi Express</span>
  						<input type="checkbox">
					</label>
					<br>
         			<label>
         				<span>Moterway Express</span>
  						<input type="checkbox">
					</label><br>	
         		</div>
         </div>
    <form method="POST" action="/receipt1"> 
    <?php echo e(csrf_field()); ?>   
         <div class="rightonerec">
            <div class="receipt">
                <div class="rrec1">
             		<h2>Booking Details</h2>
                </div>
                <div class="rrec2">


                <?php $__currentLoopData = $slips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               
                    <li class="li1"><?php echo e(strtoupper($slip->latest()->first()->from)); ?></li>
                 
                    <div class="vl"></div>

                    <li class="li2"><?php echo e(strtoupper($slip->latest()->first()->where)); ?> </li>
                </div>
                <?php break; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $slips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="rrec3">
                        <?php echo e(ucwords($slip->latest()->first()->service_name)); ?> - <span style="color:green">
                        <?php echo e(ucwords($slip->latest()->first()->service_type)); ?></span>
                    </div>
                    <?php break; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = $slips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="rrec3">
                        <?php echo e($slip->latest()->first()->no_of_seats); ?> Seats
                </div>
                <?php break; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="rrec3"> 
                    Date:
                        <?php echo e($slip->latest()->first()->date); ?>


                </div>
                
                
                <div class="rrec3">Thank you   
                <?php $__currentLoopData = $slips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span style="color:green"><?php echo e(ucwords($slip->latest()->first()->name)); ?></span>
                <?php break; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                for using <span style="color:green">SAWARI</span>
                 </div>


        </div>       
        </div>
    </form>
           
            
            <div class = "finalbutton">   
                      <a href="/" ><button>Finish</button></a>
                </div>
                
   
    </body>
</html><?php /**PATH C:\Users\Atif Ur Rahman\dailybus\resources\views/receipt.blade.php ENDPATH**/ ?>