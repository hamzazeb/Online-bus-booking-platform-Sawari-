<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <style>
        	h1{
        		text-align: center;
        	}
        	.nameshere{
        		width=20px;
        		margin-left: 400px;
        		
        		padding:20px;
        	}
        	table{
        		width:100%;
        	}
        	table, th, td {
 				 border: 1px solid black;
 				 padding:5px;
 				 font-family: calibri;
 				 font-size: 18px;
			}
			th {
  				height: 30px;
  				background-color: orange;
                font-family: raleway;
  				color:black;
  				font-size: 17px;
			}
			td:hover{
				border-bottom-color:red;
			}
                .welcome{
                    font-size: 23px;
                    font-family: raleway;
                    text-align: right;
                    padding:10px;

                }
                 span{
                    line-height: 80px;
                    color:white;
                    font-family: raleway;
                }
                .welcome1 button{
                    font-size: 16px;
                    font-family: raleway;
                    text-align: center;
                    padding:10px;
                    color:white;
                    background-color:orange;
                    float:right;
                    margin-top: -65px;
                    margin-right: 20px;
                    opacity: 0.8px;
                }

                #welcomediv{
                    height: 83px;
                    width:100%;
                    background-color: #F5BCBA;
                }
                .addfacilities{
                    font-weight: bold;
                    font-size: 18px;
                    font-family: raleway;

                }
                .facility{
                    float: right;
                    margin-top: -100px;
                }
        </style>
    </head>
    <body>

        @if(isset(Auth::user()->email))
    <div class="alert alert-danger success-block" id="welcomediv">
     <span class="welcome">Welcome <strong style="text-decoration: underline;">{{ Auth::user()->name }}</strong></span>
     <br />
     <a class="welcome1" href="{{ url('/main/logout') }}"><button>Logout</button></a>
    </div>
   @else
    <script>window.location = "/main";</script>
   @endif

        <h1>List of Services</h1>
        <div class="facility"><a href="/facilities/create" class = "addfacilities">Add Facilities</a><span style="color:red;"> - Remember Service Id&nbsp&nbsp&nbsp</span></div>
        <table>
        	<tr>
                <th>Service ID</th>
        		<th>Service Name</th>
                <th>Type</th>
                <th>From</th>
                <th>To</th>
                <th>Departure</th>
                <th>Duration</th>
                <th>Arrival</th>
                <th>Fare</th>
        	</tr>
        	@foreach ($projects as $project)
        	<tr>
                <td>{{ $project->id }}</td>
        		<td>{{ $project->service_name }}</td>
                <td>{{ $project->service_type }}</td>
                <td>{{ $project->sfrom }}</td>
                <td>{{ $project->sto }}</td>
                <td>{{ $project->departure }}</td>
                <td>{{ $project->duration }}</td>
                <td>{{ $project->arrival }}</td>
                <td>{{ $project->fare }}</td>
        	</tr>
        	@endforeach
        </table>


   <!--      @foreach ($projects as $project)

          <li>{{ $project->service_name }}</li>    

@endforeach
-->
    </body>
</html>