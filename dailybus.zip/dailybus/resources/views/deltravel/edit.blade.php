<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <style>
            h1{
                text-align: center;
            }
            .nameshere{
                width=20px;
                margin-left: 400px;
                
                padding:20px;
            }
            table{
                width:100%;
            }
            table, th, td {
                 border: 1px solid black;
                 padding:5px;
                 font-family: calibri;
                 font-size: 18px;
            }
            th {
                height: 30px;
                background-color: orange;
                font-family: raleway;
                color:black;
                font-size: 17px;
            }
            td:hover{
                border-bottom-color:red;
            }

        </style>
    </head>
    <body>

        <h1>List of Travels</h1>
        

    </body>
</html>