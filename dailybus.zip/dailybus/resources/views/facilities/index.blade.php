<!DOCTYPE html>
<html>
    <head>
        <title>Facilities</title>
        <style>
        	h1{
        		text-align: center;
        	}
        	.nameshere{
        		width=20px;
        		margin-left: 400px;
        		
        		padding:20px;
        	}
        	table{
        		width:100%;
        	}
        	table, th, td {
 				 border: 1px solid black;
 				 padding:5px;
 				 font-family: calibri;
 				 font-size: 18px;
                 text-align:center;
			}
			th {
  				height: 30px;
  				background-color: orange;
                font-family: raleway;
  				color:black;
  				font-size: 17px;
			}
			td:hover{
				border-bottom-color:red;

			}

        </style>
    </head>
    <body>
   @if(isset(Auth::user()->email))
    <div class="alert alert-danger success-block" id="welcomediv">
     <span class="welcome">Welcome <strong style="text-decoration: underline;">{{ Auth::user()->name }}</strong></span>
     <br />
     <a class="welcome1" href="{{ url('/main/logout') }}"><button>Logout</button></a>
    </div>
   @else
    <script>window.location = "/main";</script>
   @endif
        <h1>Facilities</h1>
        
            <table>
            <tr>
                <th>Service ID</th>
                <th>WiFi</th>
                <th>Refreshment</th>
                <th>Newspaper</th>
                <th>AC</th>
                <th>Entertainment</th>
            </tr>
            @foreach ($facilities as $facilitie)
            <tr>
                <td>{{ $facilitie->service_id }}</td>
                <td>{{ $facilitie->Wifi }}</td>
                <td>{{ $facilitie->Refreshment }}</td>
                <td>{{ $facilitie->Newspaper }}</td>
                <td>{{ $facilitie->AC }}</td>
                <td>{{ $facilitie->Entertainment }}</td>
            </tr>
            @endforeach
        </table>
    </body>
</html>