<!DOCTYPE html>
<html>
    <head>
        <title>Customer Details</title>
        <link href="{{ asset('css/stylesformain.css') }}" rel="stylesheet">
        <link href="{{ asset('css/stylesheet.css') }}" rel="stylesheet">
    </head>

    <body>
      <div class="bookingmenu">
        <div class="logodiv">
            <a href="/"><img class="logo" src="/images/logo.png" \></a>
        </div>

        <div class="menudiv">
        <ul >
            <li><a href="/" >Find a Sawari</a></li>
            <li><a href="/help" >Help</a></li>
            <li><a href="/about" >About Us</a></li>
        </ul>
        <div>
            <a href="/"><img src="/images/userProfileBlack.png" \></a>
        </div>
        </div>
      </div>
        
      <div class="bookingcontainer">
         <div class="leftone">
         		<div class="lfirst">
         			<strong>Sort By</strong><br>

         			<button>Fare</button>
         			<button>Time</button>
         			
         		</div>	
         		<div class="lsecond">
         			<strong>FILTERS</strong>
         			<br><br>
         			<label>
         				<span>Air-Conditioned</span>
  						<input type="checkbox">
					</label><br>
					<label>
         				<span>Refreshments</span>
  						<input type="checkbox">
					</label><br>
					<label>
         				<span>Entertainment System</span>
  						<input type="checkbox">
					</label>
         		</div>

         		<div class="lthird"><br>
         			<strong>Departures</strong>
         			<br>
         			<label>
         				<span>Day time</span>
  						<input type="checkbox">
					</label><br>
					<label>
         				<span>Night time</span>
  						<input type="checkbox">
					</label><br>	
         		</div>
         		<div class="lfourth"><br>
         			<strong>Bus Service</strong>
         			<br>
         			<label>
         				<span>Daewoo Express</span>
  						<input type="checkbox">
					</label><br>
					<label>
         				<span>Faisal Movers</span>
  						<input type="checkbox">
					</label>
					<br>
         			<label>
         				<span>Bilal Travels</span>
  						<input type="checkbox">
					</label><br>
					<label>
         				<span>Islamabad Express</span>
  						<input type="checkbox">
					</label>
					<br>
         			<label>
         				<span>Pindi Coaches</span>
  						<input type="checkbox">
					</label><br>
					<label>
         				<span>Niazi Express</span>
  						<input type="checkbox">
					</label>
					<br>
         			<label>
         				<span>Moterway Express</span>
  						<input type="checkbox">
					</label><br>	
         		</div>
         </div>
        
         <div class="rightonecus">
         	<h2>Customer Details</h2>
            
            
<form method="POST" action="/booking">
      {{ csrf_field() }}
                <span>Name</span><br>
                <input type="text" id="date" name="name" placeholder=""><br><br>

                <span>CNIC</span><br>
                <input type="text" id="date" name="cnic" placeholder=""><br><br>

                <span>Mobile</span><br>
                <input type="text" id="date" name="mobile" placeholder=""><br><br>
                
                <br>
                <button type = "submit">PROCEED</button>
</form>           
         </div>
     </div>

    </body>
</html>