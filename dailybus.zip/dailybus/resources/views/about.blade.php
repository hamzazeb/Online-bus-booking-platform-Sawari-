<!DOCTYPE html>
<html>
    <head>
        <title>About Us</title>
        <link href="{{ asset('css/stylesformain.css') }}" rel="stylesheet">
        <link href="{{ asset('css/stylesheet.css') }}" rel="stylesheet">
    </head>

    <body>
      <div class="bookingmenu">
        <div class="logodiv">
            <a href="/"><img class="logo" src="/images/logo.png" \></a>
        </div>

        <div class="menudiv">
        <ul >
            <li><a href="/" >Find a Sawari</a></li>
            <li><a href="/help" >Help</a></li>
            <li><a href="/about" >About Us</a></li>
        </ul>
        <div>
            <a href="/"><img src="/images/userProfileBlack.png" \></a>
        </div>
        </div>
      </div>
    
    <div class="aboutcontainer">
      <img src="/images/wis.jpg" \>
      <br>
      <p>
      	Sawari is an online bus guide which compares fares of bus rides in different cities of Pakistan and lists them, allowing the user to choose a service based on their budget. The system is first of its kind in Pakistan.<br><br>
      </p>
      <br>
      <hr>
  	</div>
        
    </body>
</html>