<!DOCTYPE html>
<html>
    <head>
        <title>Booking</title>
        <link href="{{ asset('css/stylesformain.css') }}" rel="stylesheet">
        <link href="{{ asset('css/stylesheet.css') }}" rel="stylesheet">
    </head>

    <body>
      <div class="bookingmenu">
        <div class="logodiv">
            <a href="/"><img class="logo" src="/images/logo.png" \></a>
        </div>

        <div class="menudiv">
        <ul >
            <li><a href="/" >Find a Sawari</a></li>
            <li><a href="/help" >Help</a></li>
            <li><a href="/about" >About Us</a></li>
        </ul>
        <div>
            <a href="/"><img src="/images/userProfileBlack.png" \></a>
        </div>
        </div>
      </div>
        
      <div class="bookingcontainer">
         <div class="leftone">
         		<div class="lfirst">
         			<strong>Sort By</strong><br>

         			<button>Fare</button>
         			<button>Ratings</button>
         			<button>Seats</button>
         		</div>	
         		<div class="lsecond">
         			<strong>FILTERS</strong>
         			<br><br>
         			<label>
         				<span>Air-Conditioned</span>
  						<input type="checkbox">
					</label><br>
					<label>
         				<span>Refreshments</span>
  						<input type="checkbox">
					</label><br>
					<label>
         				<span>Entertainment System</span>
  						<input type="checkbox">
					</label>
         		</div>

         		<div class="lthird"><br>
         			<strong>Departures</strong>
         			<br>
         			<label>
         				<span>Day time</span>
  						<input type="checkbox">
					</label><br>
					<label>
         				<span>Night time</span>
  						<input type="checkbox">
					</label><br>	
         		</div>
         		<div class="lfourth"><br>
         			<strong>Bus Service</strong>
         			<br>
         			<label>
         				<span>Daewoo Express</span>
  						<input type="checkbox">
					</label><br>
					<label>
         				<span>Faisal Movers</span>
  						<input type="checkbox">
					</label>
					<br>
         			<label>
         				<span>Bilal Travels</span>
  						<input type="checkbox">
					</label><br>
					<label>
         				<span>Islamabad Express</span>
  						<input type="checkbox">
					</label>
					<br>
         			<label>
         				<span>Pindi Coaches</span>
  						<input type="checkbox">
					</label><br>
					<label>
         				<span>Niazi Express</span>
  						<input type="checkbox">
					</label>
					<br>
         			<label>
         				<span>Moterway Express</span>
  						<input type="checkbox">
					</label><br>	
         		</div>
         </div>
      
         <div class="rightone">
         		<div class="rfirst">
                    <div class="rfirst1" >
                       
                    </div>
                    <div><b>Departure</b></div>
                    <div><b>Duration</b></div>
                    <div><b>Arrival</b></div>
                    <div><b>Fare</b></div>
                    
        
                    <div class="rfirst6"> <b>Send Payment At</b></div>

                </div>
      
                
                @foreach ($projects as $project)

                @if( $travels1 == $project->sfrom and $travels2 == $project->sto)

         		<div class="rsecond">
                    <div class="rsecond1" name="service_name1" value="{{$project->service_name}}"><b>{{ strtoupper($project->service_name) }} - <span style="color:green;font-size: 13px;">{{ strtoupper($project->service_type) }}</span></b>
                        <br>
                         @foreach ($facilities as $facilitie)
                        @if($facilitie->service_id == $project->id)
                            @if($facilitie->Wifi == 1)
                                <img class="rs1" src="/images/facilities/wifi.png" \>
                            @else
                                <b></b>
                            @endif

                            @if($facilitie->Refreshment == 1)
                                <img class="rs2" src="/images/facilities/refreshment.png" \>
                            @else
                                <b></b>
                            @endif

                            @if($facilitie->Newspaper == 1)
                                <img class="rs3" src="/images/facilities/newspaper.png" \>
                            @else
                                <b></b>
                            @endif

                            @if($facilitie->AC == 1)
                                <img class="rs4" src="/images/facilities/ac.png" \>
                            @else
                                <b></b>
                            @endif

                            @if($facilitie->Entertainment == 1)
                                <img class="rs4" src="/images/facilities/entertainment.png" \>
                            @else
                                <b></b>
                            @endif
                        @endif                
                    @endforeach 

                    </div>
                    <div style="color:green;font-size: 21px" name="departure1" value="{{$project->departure}}">
                        {{ $project->departure }}
                    </div>
                    <div style="color:brown;font-size: 21px" name="duration1" value="{{$project->duration}}">
                        {{ $project->duration }}h
                    </div>
                    <div style="font-size: 21px" name="arrival1" value="{{$project->arrival}}">
                        {{ $project->arrival }}
                    </div>
                    <div style="font-size: 21px" name="fare1" value="{{$project->fare}}">
                        PKR {{ $project->fare }}
                    </div>
                    <div class="rsecond6">
                            <span>Acc # 03165467510</span><br><br>
                            <a href="https://www.easypaisa.com.pk/easypay/onlinepayments" target="_blank"><img src="/images/easypaisa.png"></a>
                            
                        
                    </div>
                </div>
         @endif  
                @endforeach

                

<form method="POST" action="/receipt">
      {{ csrf_field() }}
      <br>
            <label ><span>Select You Service Here</span></label>
            <select style="margin-left: 18px;"  type="text" id="randommm" name="service_name" placeholder="">
                <option value="daeweoo express">DAEWOO EXPRESS</option>
                <option value="moterway express">MOTERWAY EXPRESS</option>
                <option value="niazi express">NIAZI EXPRESS</option>                        
                <option value="bilal travels">BILAL TRAVELS</option>
                <option value="faisal movers">FAISAL MOVERS</option>
            </select>
<br>
            <label ><span>Select Service Type</span></label>
            <select style="margin-left: 53px;" type="text" id="randommm" name="service_type" placeholder="">
                <option value="bus">Bus</option>
                <option value="hiace">Hiace</option>
                <option value="cargo">Cargo</option>
            </select>
<br>

            <label ><span>Select No of Seats</span></label>
            <select style="margin-left: 64px;" type="text" id="randommm" name="no_of_seats" placeholder="">
                <option value=1>1</option>
                <option value=2>2</option>
                <option value=3>3</option>
                <option value=4>4</option>
            </select>   
            

             <button  type="submit" class="randomm">BOOK MY SAWARI</button>
                    
    </form>           
         		
         </div>
         
     </div>

    </body>
</html>