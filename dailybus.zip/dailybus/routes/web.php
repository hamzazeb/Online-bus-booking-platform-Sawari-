<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'PagesController@home');
Route::get('/about', 'PagesController@about');
Route::get('/contact', 'PagesController@contact');
Route::get('/booking', 'PagesController@booking');
Route::get('/customer', 'PagesController@customer');
Route::get('/help', 'PagesController@help');
Route::get('/receipt', 'PagesController@receipt');


Route::get('/main', 'MainController@index');
Route::post('/main/checklogin', 'MainController@checklogin');
// Route::get('main/successlogin', 'MainController@successlogin');
Route::get('/projects/create', 'MainController@successlogin');
Route::get('main/logout', 'MainController@logout');

//Route::get('/projects', 'AllServicesController@index');

Route::get('/projects', 'ProjectsController@index');
Route::post('/projects', 'ProjectsController@store');
Route::get('/projects/create', 'ProjectsController@create');



Route::get('/facilities', 'FacilitiesController@index');
Route::post('/facilities', 'FacilitiesController@store');
Route::get('/facilities/create', 'FacilitiesController@create');



//Route::get('/', 'UsersController@index');
Route::post('/welcome', 'TravelController@store');
//Route::get('/', 'UsersController@create');

Route::post('/receipt', 'ServiceController@store');


Route::post('/booking', 'MembersController@store');

Route::post('/receipt1', 'PagesController@receipt1');




Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
