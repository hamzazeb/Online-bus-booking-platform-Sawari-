<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSlipsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('slips', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('from')->nullable()->default(NULL);
            $table->string('where')->nullable()->default(NULL);
            $table->string('service_name')->nullable()->default(NULL);
            $table->string('service_type')->nullable()->default(NULL);
            $table->integer('no_of_seats')->nullable()->default(NULL);
            $table->string('date')->nullable()->default(NULL);
            $table->string('name')->nullable()->default(NULL);
            $table->bigInteger('travel_id')->unsigned()->nullable()->default(NULL);
            $table->timestamps();
            $table->engine = 'InnoDB';

            $table->foreign('travel_id')
            ->references('id')
            ->on('travels')
            ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('slips');
    }
}
