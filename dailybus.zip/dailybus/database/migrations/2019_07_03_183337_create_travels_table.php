<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTravelsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('travels', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->biginteger('member_id')->unsigned()->nullable()->default(NULL);
            $table->biginteger('types_id')->unsigned()->nullable()->default(NULL);
            $table->string('from');
            $table->string('where');
            $table->string('date');
            $table->timestamps();
            $table->engine = 'InnoDB';

            $table->foreign('member_id')
            ->references('id')
            ->on('members')
            ->onDelete('cascade');

            $table->foreign('types_id')
            ->references('id')
            ->on('types')
            ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('travels');
    }
}
