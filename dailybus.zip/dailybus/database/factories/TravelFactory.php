<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Travel;
use Faker\Generator as Faker;

$factory->define(Travel::class, function (Faker $faker) {
    return [
        //
    ];
});
